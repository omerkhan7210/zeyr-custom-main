import express from 'express';
import { hash, compare } from 'bcrypt';
import jwt from 'jsonwebtoken';
import cors from 'cors';
import mysql from 'mysql';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import nodemailer from 'nodemailer';
import crypto from 'crypto';


const app = express();
app.use(cors());
app.use(express.json());
app.use(cookieParser());
app.use(session({
  secret: 'session-secret', // Update with your session secret
  resave: false,
  saveUninitialized: false,
}));



// MySQL connection pool configuration
const pool = mysql.createPool({
  host: 'localhost', // Update with your MySQL server host
  user: 'zeyr', // Update with your MySQL username
  password: '', // Update with your MySQL password
  database: 'zeyr-custom', // Update with your MySQL database name
});

// JWT secret key
const jwtSecret = 'secret-key';

// Generate a random 4-digit OTP code
function generateOTP() {
  const otp = Math.floor(1000 + Math.random() * 9000);
  return otp.toString();
}

// Store the OTP codes for verification
const otpCodes = {};

function sendOtpCodeToEmail(email,otpCode){
   // Send password reset email
   const mailOptions = {
    from: 'omerfarooqkhan7210@gmail.com', // Update with your email
    to: email,
    subject: 'Password Reset',
    text: `Your OTP code for password reset is: ${otpCode}`,
  };

  // Create a transporter object with your Gmail account details
const transporter = nodemailer.createTransport({
service: 'gmail',
auth: {
user: 'omerfarooqkhan7210@gmail.com', // Your Gmail email address
pass: 'eaermqekncdsjnsn', // Your Gmail password or app-specific password
},
});

  transporter.sendMail(mailOptions, (error) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ message: 'Failed to send password reset email' });
    }

    res.status(200).json({ message: 'Password reset email sent' });
  });
}

app.get('/', (req,res)=>{
    res.send ("hello world")
})

// Route for user signup
app.post('/signup', async (req, res) => {
  try {
    const { fname, lname, email, password } = req.body;

    // Check if email is already taken
    pool.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ message: 'Server error' });
      }

      // Check if email already exists
      if (results.length > 0) {
        return res.status(409).json({ message: 'Email already exists' });
      }

      // Generate OTP code (4-digit code)
      const otpCode = Math.floor(1000 + Math.random() * 9000);

      // Store the OTP code in a temporary object
      otpCodes[email] = otpCode;

      // Send the OTP code to the user's email (using your preferred email sending method/library)
      sendOtpCodeToEmail(email, otpCode); // Replace with your email sending logic

      // Hash the password
      const hashedPassword = await hash(password, 10);

      // Insert the user into the database
      pool.query(
        'INSERT INTO users (fname, lname, email, password) VALUES (?, ?, ?, ?)',
        [fname, lname, email, hashedPassword],
        (error) => {
          if (error) {
            console.error(error);
            return res.status(500).json({ message: 'Server error' });
          }

          // Generate JWT token
          const token = jwt.sign({ email }, jwtSecret , { expiresIn: '1h' });

          // Store the token in session or cookies
          // req.session.token = token;
          // Alternatively, you can use cookies:
          res.cookie('token', token, { httpOnly: true });

          return res.status(201).json({ message: 'Success', otpCode });
        }
      );
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});


// Route for verifying OTP
app.post('/verify-otp', async (req, res) => {
  try {
    const { email, otpCode } = req.body;

    // Check if the OTP code is valid for the given email
    if (otpCodes[email] === otpCode) {
      // Clear the OTP code from temporary storage
      delete otpCodes[email];


      return res.status(200).json({ message: 'OTP verification successful' });
    } else {
      return res.status(400).json({ message: 'Invalid OTP code' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});


// Route for user login
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find the user in the database
    pool.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ message: 'Server error' });
      }

      // Check if user exists
      if (results.length === 0) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }

      const user = results[0];
      // Compare the password
      const isPasswordValid = await compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }

      // Generate a JWT token
      const token = jwt.sign({ email }, jwtSecret , { expiresIn: '1h' });

      res.cookie('token', token, { httpOnly: true });

      res.status(200).json({ message: 'Login successful', token });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Route for password reset
app.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

     // Generate OTP code
     const otpCode = generateOTP();

     // Store the OTP code for verification
     otpCodes[email] = otpCode;
 

    // Find the user in the database
    pool.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ message: 'Server error' });
      }

      // Check if user exists
      if (results.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      const user = results[0];
      const resetToken = jwt.sign({ email }, jwtSecret, { expiresIn: '1h' });

      res.cookie('token', resetToken, { httpOnly: true });

      sendOtpCodeToEmail(email, otpCode); // Replace with your email sending logic
      
     
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});


// Route for verifying OTP code and resetting password
app.post('/reset-password', async (req, res) => {
  try {
    const { email, otpCode, newPassword } = req.body;

    // Verify OTP code
    if (otpCodes[email] !== otpCode) {
      return res.status(400).json({ message: 'Invalid OTP code' });
    }

    // Find the user in the database
    pool.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ message: 'Server error' });
      }

      // Check if user exists
      if (results.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Hash the new password
      const hashedPassword = await hash(newPassword, 10);

      // Update the user's password in the database
      pool.query('UPDATE users SET password = ? WHERE email = ?', [hashedPassword, email], (error) => {
        if (error) {
          console.error(error);
          return res.status(500).json({ message: 'Server error' });
        }

        // Clear the OTP code after successful verification
        delete otpCodes[email];

        res.status(200).json({ message: 'Password reset successful' });
      });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});


// Route for fetching user account details
app.get('/account-details', async (req, res) => {
  try {
    const token = req.headers.authorization.split(' ')[1]; // Extract the JWT token from the authorization header

    // Verify the JWT token and extract the user information
    const decoded = jwt.verify(token, jwtSecret);

    // Assuming you have a 'users' table in your MySQL database
    // Replace this query with your own logic to fetch the user account details
    const query = 'SELECT fname , lname , email FROM users WHERE email = ?';
    pool.query(query, [decoded.email], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ message: 'Server error' });
      }

      if (results.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      const user = results[0];
      res.status(200).json({
        fname: user.fname,
        lname: user.lname,
        email: user.email,
      });
    });
  } catch (error) {
    console.error(error);
    res.status(401).json({ message: 'Invalid token' });
  }
});



const port = process.env.PORT || 5000; // Use the environment variable PORT if available, otherwise use port 5000
const host = process.env.HOST || 'localhost'; // Use the environment variable HOST if available, otherwise use 'localhost'

app.listen(port, host, () => {
  console.log(`Server is running on ${host}:${port}`);
});